﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Data.Pdf;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

namespace InSenseDemo.UWP
{
    public sealed partial class MainPage : INotifyPropertyChanged
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public ObservableCollection<BitmapImage> PdfPages
        {
            get;
            set;
        } = new ObservableCollection<BitmapImage>();
        public bool ColumnVisibility = false;
        public int ResumeCount = 1;
        private String _Pane1Text = "";
        public String Pane1Text
        {
            get { return _Pane1Text;  }
            set { _Pane1Text = value; OnPropertyChanged("Pane1Text"); }
        }

        void OnPropertyChanged(String prop)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private GridLength _IsColumnVisible;
        private GridLength _MainViewAdjust;
        private bool _CommentsEnabled;
        public bool CommentsEnabled
        {
            get { return _CommentsEnabled; }
            set { _CommentsEnabled = value; OnPropertyChanged("CommentsEnabled"); }
        }
        private bool _SelectionEnabled;
        public bool SelectionEnabled
        {
            get { return _SelectionEnabled; }
            set { _SelectionEnabled = value; OnPropertyChanged("SelectionEnabled"); }
        }
        public GridLength IsColumnVisible
        {
            get { return _IsColumnVisible; }
            set { _IsColumnVisible = value; OnPropertyChanged("IsColumnVisible"); }
        }
        public GridLength MainViewAdjust
        {
            get { return _MainViewAdjust; }
            set { _MainViewAdjust = value; OnPropertyChanged("MainViewAdjust"); }
        }
        private bool _CategorySelected = false;
        public bool CategorySelected
        {
            get { return _CategorySelected; }
            set { _CategorySelected = value; OnPropertyChanged("CategorySelected"); }
        }
        private String _Counter = "1/100";
        public string Counter
        {
            get { return _Counter; }
            set { _Counter = (value + "/100"); OnPropertyChanged("Counter");  }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        int _Value = default(int);
        public int Value
        {
            get { return _Value; }
            set
            {
                _Value = value;
                OnPropertyChanged("ValueAs1");
                OnPropertyChanged("ValueAs2");
                OnPropertyChanged("ValueAs3");
                OnPropertyChanged("ValueAs4");
                CategorySelected = true;
            }
        }
        public bool ValueAs1
        {
            get { return Value.Equals(1); }
            set { Value = 1; }
        }
        public bool ValueAs2
        {
            get { return Value.Equals(2); }
            set { Value = 2; }
        }
        public bool ValueAs3
        {
            get { return Value.Equals(3); }
            set { Value = 3; }
        }
        public bool ValueAs4
        {
            get { return Value.Equals(4); }
            set { Value = 4; }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public MainPage()
        {
            ColumnVisibility = true;
            CommentsEnabled = false;
            SelectionEnabled = true;
            Pane1Text = "How would you categorize this resume? What job type is this candidate applying for?";
            columnSetter();
            this.InitializeComponent();
            this.DataContext = this;
            OpenLocal("ms-appx:///Assets/1.pdf");
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        private async Task SendEmail(Windows.ApplicationModel.Contacts.Contact recipient, string messageBody, StorageFile attachmentFile)
        {
            var emailMessage = new Windows.ApplicationModel.Email.EmailMessage();
            emailMessage.Body = messageBody;

            if (attachmentFile != null)
            {
                var stream = Windows.Storage.Streams.RandomAccessStreamReference.CreateFromFile(attachmentFile);

                var attachment = new Windows.ApplicationModel.Email.EmailAttachment(
                    attachmentFile.Name,
                    stream);

                emailMessage.Attachments.Add(attachment);
            }

            var email = recipient.Emails.FirstOrDefault<Windows.ApplicationModel.Contacts.ContactEmail>();
            if (email != null)
            {
                var emailRecipient = new Windows.ApplicationModel.Email.EmailRecipient(email.Address);
                emailMessage.To.Add(emailRecipient);
            }

            await Windows.ApplicationModel.Email.EmailManager.ShowComposeNewEmailAsync(emailMessage);
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public async void OpenLocal(String uriPass)       
        {
            try {
                StorageFile storageFile = await StorageFile.GetFileFromApplicationUriAsync(new Uri(uriPass, UriKind.Absolute));
                PdfDocument pdfDoc = await PdfDocument.LoadFromFileAsync(storageFile);

                Load(pdfDoc);
            }
            catch (FileNotFoundException error) { ResumeCount--; DisplayEndOfListDialog();  }
            
        }

        async void Load(PdfDocument pdfDoc)
        {
            PdfPages.Clear();

            for (uint i = 0; i < pdfDoc.PageCount; i++)
            {
                BitmapImage image = new BitmapImage();

                var page = pdfDoc.GetPage(i);

                using (InMemoryRandomAccessStream stream = new InMemoryRandomAccessStream())
                {
                    await page.RenderToStreamAsync(stream);
                    await image.SetSourceAsync(stream);
                }

                PdfPages.Add(image);
            }
        }

        private async void DisplayConfirmDialog()
        {
            ContentDialog confirm = new ContentDialog
            {
                Title = "Confirmations",
                Content = "Do you know what's gonna happen?",
                PrimaryButtonText = "Heck Ya",
                SecondaryButtonText = "Wait Wat"
            };

            ContentDialogResult result = await confirm.ShowAsync();
            if(result == ContentDialogResult.Primary)
            {
                LoadNext();
            }
            else
            {
                //Do Nothing
            }
        }

        private async void DisplayEndOfListDialog()
        {
            ContentDialog confirm = new ContentDialog
            {
                Title = "You're All Done!",
                Content = "You've reached the end of the list! Thanks for all your help",
                PrimaryButtonText = "Woohoo!"
            };

            ContentDialogResult result = await confirm.ShowAsync();
        }

        public void LoadNext_Tapped(object sender, RoutedEventArgs e)
        {
            if(ResumeCount == 1)
            {
                DisplayConfirmDialog();
            }
            else
            {
                LoadNext();
            }
        }

        private void LoadNext()
        {
            ResumeCount++;
            String fileName = "ms-appx:///Assets/" + ResumeCount + ".pdf";
            OpenLocal(fileName);
            Counter = ResumeCount.ToString();
            Value = 0;
            CategorySelected = false;
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Questions_Tapped(object sender, TappedRoutedEventArgs e)
        {
            var email = new Windows.ApplicationModel.Contacts.ContactEmail();
            email.Address = "ayush.rohatgi@ge.com";
            var contact = new Windows.ApplicationModel.Contacts.Contact();
            contact.Emails.Add(email);
            SendEmail(contact, "", null);
        }

        private void Comments_Tapped(object sender, TappedRoutedEventArgs e)
        {
            if (ColumnVisibility && !SelectionEnabled)
            {
                ColumnVisibility = false;
                CommentsEnabled = false;
                SelectionEnabled = false;
                Pane1Text = "";
            }
            else
            {
                ColumnVisibility = true;
                CommentsEnabled = true;
                SelectionEnabled = false;
                Pane1Text = "Enter a comment about this resume. Your entry is saved when you classify a resume.";
            }
            columnSetter();
        }

        private void Resumes_Tapped(object sender, TappedRoutedEventArgs e)
        {
            if (ColumnVisibility && !CommentsEnabled)
            {
                ColumnVisibility = false;
                CommentsEnabled = false;
                SelectionEnabled = false;
                Pane1Text = "";
            }
            else
            {
                ColumnVisibility = true;
                CommentsEnabled = false;
                SelectionEnabled = true;
                Pane1Text = "How would you categorize this resume? What job type is this candidate applying for?";
            }
            columnSetter();
        }

        private void LoadResume_Tapped(object sender, TappedRoutedEventArgs e)
        {

        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        private void columnSetter()
        {
            BooleanToGridLengthConverter();
            BooleanToGridLengthConverter2();
            this.InitializeComponent();
        }

        private void BooleanToGridLengthConverter()
        {
            if (ColumnVisibility)
            {
                IsColumnVisible = new GridLength(1, GridUnitType.Star);
            }
            else
            {
                IsColumnVisible = new GridLength(0);
            }
        }

        private void BooleanToGridLengthConverter2()
        {
            if (ColumnVisibility)
            {
                MainViewAdjust = new GridLength(4, GridUnitType.Star);
            }
            else
            {
                MainViewAdjust = new GridLength(1, GridUnitType.Star);
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public async Task ssoAsync()
        {
            string startURL = "https://<providerendpoint>?client_id=<clientid>&scope=<scopes>&response_type=token";
            string endURL = "http://<appendpoint>";

            System.Uri startURI = new System.Uri(startURL);
            System.Uri endURI = new System.Uri(endURL);

            String result;

            try
            {
                var webAuthenticationResult =
                    await Windows.Security.Authentication.Web.WebAuthenticationBroker.AuthenticateAsync(
                    Windows.Security.Authentication.Web.WebAuthenticationOptions.None,
                    startURI);

                switch (webAuthenticationResult.ResponseStatus)
                {
                    case Windows.Security.Authentication.Web.WebAuthenticationStatus.Success:
                        // Successful authentication. 
                        result = webAuthenticationResult.ResponseData.ToString();
                        break;
                    case Windows.Security.Authentication.Web.WebAuthenticationStatus.ErrorHttp:
                        // HTTP error. 
                        result = webAuthenticationResult.ResponseErrorDetail.ToString();
                        break;
                    default:
                        // Other error.
                        result = webAuthenticationResult.ResponseData.ToString();
                        break;
                }
            }
            catch (Exception ex)
            {
                // Authentication failed. Handle parameter, SSL/TLS, and Network Unavailable errors here. 
                result = ex.Message;
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////
    }
}
